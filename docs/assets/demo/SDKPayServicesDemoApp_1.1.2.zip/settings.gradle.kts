pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
val azureUsername = providers.gradleProperty("azureUsername")
val azurePassword = providers.gradleProperty("azurePassword")

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        flatDir {
            dirs("libs")
        }

        maven{
            name="SDK_UNICO"
            url= uri("https://pkgs.dev.azure.com/stndtef/SmartPOS/_packaging/SDK_UNICO/maven/v1")
            credentials{
                username = azureUsername.orNull
                password =  azurePassword.orNull
            }
        }
    }
}

rootProject.name = "Paykit Test SDK"
include(":app")
 