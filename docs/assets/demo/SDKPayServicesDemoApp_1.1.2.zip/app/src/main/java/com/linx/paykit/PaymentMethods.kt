package com.linx.paykit

import androidx.compose.material3.TextField
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linx.paykit.common.Callback
import com.linx.paykit.common.OrderItem
import com.linx.paykit.common.Paykit
import com.linx.paykit.common.PaymentResult
import com.linx.paykit.common.parameter.CreditParameters
import com.linx.paykit.common.parameter.DebitParameters
import com.linx.paykit.common.parameter.PaymentParameters
import com.linx.paykit.common.parameter.VoucherParameters
import com.linx.paykit.common.parameter.type.CreditTransactionType
import com.linx.paykit.common.parameter.type.DebitTransactionType
import com.linx.paykit.common.parameter.type.MethodType
import com.linx.paykit.common.parameter.type.PaymentMethod
import com.linx.paykit.common.parameter.type.PaymentType
import com.linx.paykit.common.parameter.type.TransactionType
import com.linx.paykit.common.parameter.type.VoucherTransactionType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.math.BigDecimal

fun startPayment(
    paykit: Paykit,
    amount: BigDecimal,
    paymentType: PaymentType,
    transactionType: TransactionType?,
    instalments: Int?,
    postCreditDays: Int?,
    orderItems: List<OrderItem> = listOf(
        OrderItem(
            "2891820317391823",
            "dummy coke",
            0,
            1,
            "UNIDADE"
        )
    ),
    onResult: (PaymentResult) -> Unit
) {
    val callback: Callback<PaymentResult> =
        Callback { t ->
            CoroutineScope(Dispatchers.IO).launch {
                onResult(t)
            }
        }

    when (paymentType) {
        PaymentType.DEBIT-> {
            val params = DebitParameters(
                amount = amount,
                installments = instalments,
                items = orderItems,
                debitType = transactionType as? DebitTransactionType,
                postCreditDays = postCreditDays
            )
            paykit.debit(params, callback)
        }
        PaymentType.CREDIT -> {
            val params = CreditParameters(
                amount = amount,
                installments = instalments,
                items = orderItems,
                creditType = transactionType as? CreditTransactionType
            )
            paykit.credit(params, callback)
        }
        PaymentType.VOUCHER -> {
            val params = VoucherParameters(
                amount = amount,
                items = orderItems,
                voucherType = transactionType as? VoucherTransactionType
            )
            paykit.voucher(params, callback)
        }
        PaymentType.PIX -> {
            val params = PaymentParameters(amount, items = orderItems)
            paykit.pix(params, callback)
        }
        PaymentType.WALLET -> {
            val params = PaymentParameters(amount = amount)
            paykit.wallet(params, callback)
        }
    }
}

@Composable
fun PaymentMethodScreen(paykit: Paykit? = null, amount: BigDecimal, resultCallback: ((PaymentResult) -> Unit),onDismiss: () -> Unit) {
    // Mutable Ref Block
    var paymentType by remember { mutableStateOf(PaymentType.DEBIT) }
    var installments by remember { mutableIntStateOf(2) }
    var postCreditDays by remember { mutableIntStateOf(0) }
    var transactionType by remember { mutableStateOf<TransactionType>(DebitTransactionType.AT_SIGHT) }

    Text(
        text = "Tipo de pagamento",
        style = MaterialTheme.typography.bodyLarge,
        modifier = Modifier.padding(bottom = 20.dp)
    )

    paykit?.let { PaymentTypeSelector(it.paymentMethods,paymentType, transactionType,{paymentType = it},{transactionType = it}) }

    Spacer(modifier = Modifier.height(16.dp))

    Column(
        modifier = Modifier
            .fillMaxSize()
            .fillMaxWidth()
            .padding(16.dp)
            .background(Color(0xFFEFEFEF)),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (paymentType == PaymentType.DEBIT && transactionType == DebitTransactionType.POSTDATED){
            Text(text = "Prazo", style = MaterialTheme.typography.labelMedium)
            TextField(
                value = if (postCreditDays > 0) postCreditDays.toString() else "",
                onValueChange = { newValue ->
                    val digitsOnly = newValue.filter { it.isDigit() }
                    postCreditDays = digitsOnly.toIntOrNull() ?: 0
                },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number)
            )

            Spacer(modifier = Modifier.height(16.dp))
        }

        if ((paymentType == PaymentType.CREDIT && transactionType != CreditTransactionType.AT_SIGHT && transactionType != CreditTransactionType.CREDIT_1_MINUTE) || transactionType == DebitTransactionType.WITH_INSTALMENTS) {
            Text(text = "Número de Parcelas", style = MaterialTheme.typography.labelMedium)
            TextField(
                value = if (installments > 0) installments.toString() else "",
                onValueChange = { newValue ->
                    val digitsOnly = newValue.filter { it.isDigit() }
                    installments = digitsOnly.toIntOrNull() ?: 0
                },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number)
            )
        }

        Button(
            onClick = {
                paykit?.let { paykit ->
                   installments = if (transactionType == CreditTransactionType.AT_SIGHT) 1 else installments

                    startPayment(
                        paykit,
                        amount,
                        paymentType,
                        transactionType,
                        installments,
                        postCreditDays,
                        onResult = resultCallback
                    )
                }
            },
            modifier = Modifier
                .fillMaxWidth(),
        ) {
            Text(text = "Iniciar pagamento", fontSize = 18.sp)
        }

        Button(onClick = onDismiss) {
            Text("Fechar")
        }
    }
}

@Composable
fun PaymentTypeSelector(
    paymentMethods: HashMap<PaymentType, PaymentMethod>,
    selectedType: PaymentType = PaymentType.DEBIT,
    selectedTransactionType: TransactionType = DebitTransactionType.AT_SIGHT,
    onTypeChanged: ((PaymentType) -> Unit)? = null,
    onTransactionTypeChanged: ((TransactionType) -> Unit)? = null
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        paymentMethods.forEach { (paymentType, paymentMethod) ->
            PaymentTypeOption(
                paymentType = paymentType,
                paymentMethod = paymentMethod,
                isSelected = selectedType == paymentType,
                selectedTransactionType = selectedTransactionType,
                onTypeChanged = onTypeChanged,
                onTransactionTypeChanged = onTransactionTypeChanged
            )
        }
    }
}

@Composable
fun PaymentTypeOption(
    paymentType: PaymentType,
    paymentMethod: PaymentMethod,
    isSelected: Boolean,
    selectedTransactionType: TransactionType,
    onTypeChanged: ((PaymentType) -> Unit)?,
    onTransactionTypeChanged: ((TransactionType) -> Unit)?
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            RadioButton(
                selected = isSelected,
                onClick = {
                    onTypeChanged?.invoke(paymentType)
                    paymentMethod.methodTypes?.firstNotNullOfOrNull { it.key }?.let {
                        onTransactionTypeChanged?.invoke(
                            it
                        )
                    }
                }
            )
            Text(
                text = paymentMethod.label,
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.padding(start = 8.dp)
            )
        }

        if (isSelected) {
            PaymentMethodTypesList(
                methodTypes = paymentMethod.methodTypes,
                selectedTransactionType = selectedTransactionType,
                onTransactionTypeChanged = onTransactionTypeChanged
            )
        }
    }
}

@Composable
fun PaymentMethodTypesList(
    methodTypes: HashMap<TransactionType, MethodType>?,
    selectedTransactionType: TransactionType,
    onTransactionTypeChanged: ((TransactionType) -> Unit)?
) {
    methodTypes?.forEach { (transactionType, paymentType) ->
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 32.dp, top = 4.dp)
        ) {
            RadioButton(
                selected = selectedTransactionType == transactionType,
                onClick = { onTransactionTypeChanged?.invoke(transactionType) }
            )
            Text(
                text = paymentType.label,
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.padding(start = 8.dp)
            )
        }
    }
}