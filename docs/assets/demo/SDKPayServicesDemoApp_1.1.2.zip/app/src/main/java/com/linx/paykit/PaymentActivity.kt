﻿package com.linx.paykit

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linx.paykit.common.Callback
import com.linx.paykit.common.Paykit
import com.linx.paykit.common.PaymentResult
import com.linx.paykit.common.TransactionStatus
import com.linx.paykit.common.activation.ActivationParameters
import com.linx.paykit.common.activation.ActivationResult
import com.linx.paykit.common.builder.Parameters
import com.linx.paykit.common.parameter.ReceiptType
import com.linx.paykit.core.PaykitFactory
import com.linx.paykit.example.components.AmountInput
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.math.BigDecimal

class PaymentActivity : ComponentActivity() {
    lateinit var activationParameters: ActivationParameters

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val paykit = PaykitFactory().build(Parameters(this, "AppTeste", "PAYKIT_ID"))

        activationParameters = ActivationParameters("CNPJ")
        activationParameters.tef.production = false
        activationParameters.tef.token = """TOKEN_TEF"""

        setContent {
            PaymentScreen(paykit, activationParameters)
        }
    }
}

// Actions Block
fun startGenericPayment(
    paykit: Paykit,
    amount: BigDecimal,
    onResult: (PaymentResult) -> Unit
) {
    val callback: Callback<PaymentResult> =
        Callback { t ->
            CoroutineScope(Dispatchers.IO).launch {
                onResult(t)
            }
        }
    paykit.startPayment(amount, null, callback)
}

fun startActivation(
    paykit: Paykit,
    params: ActivationParameters?,
    onResult: (ActivationResult) -> Unit
) {
    val callback: Callback<ActivationResult> =
        Callback{t ->
            onResult(t)
        }

    paykit.activate(params!!, callback)
}

@Preview
@Composable
fun PaymentScreen(paykit: Paykit? = null, params: ActivationParameters? = null) {
    // Mutable Ref Block
    var amount by remember { mutableStateOf(BigDecimal.ZERO) }
    var result by remember { mutableStateOf<PaymentResult?>(null) }
    var activationResult by remember { mutableStateOf<ActivationResult?>(null) }
    val scrollState = rememberScrollState()
    val activated = remember { mutableStateOf(false) }

    var showPaymentMethods by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(scrollState)
            .background(Color(0xFFEFEFEF)),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Text(text = "Valor", style = MaterialTheme.typography.bodyLarge)
        AmountInput(amount) {
            amount = it
        }

        if (showPaymentMethods){
            PaymentMethodScreen(paykit, amount,{r -> result= r}){ showPaymentMethods = false}
        }

        Button(
            onClick = {
                paykit?.let { paykit ->
                    startActivation(
                        paykit,
                        params,
                    ) { r ->
                        activationResult = r
                        activated.value = true
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
        ) {
            Text(text = "Ativar SDK", fontSize = 18.sp)
        }

        if (!showPaymentMethods){
            Button(
                onClick = {
                    showPaymentMethods = true
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = activated.value
            ) {
                Text("Métodos de Pagamento")
            }
        }

        Button(
            onClick = {
                paykit?.let { paykit ->
                    startGenericPayment(
                        paykit,
                        amount,
                    ) { r ->
                        result = r
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth(),
            enabled = !showPaymentMethods && activated.value
        ) {
            Text(text = "Iniciar pagamento genérico", fontSize = 18.sp)
        }

        result?.let {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
                    .background(Color.LightGray)
                    .padding(16.dp)
            ) {
                Text(text = "Transaction id: ${it.id}", fontSize = 16.sp)
                Text(text = "Status: ${it.status}", fontSize = 16.sp)
                if(it.status == TransactionStatus.ERROR){
                    Text(text = "Status Message: ${it.message ?: "null"}", fontSize = 16.sp)
                }
            }
        }

        Button(
            onClick = {
                paykit?.let { paykit ->
                    paykit.printLastReceipt(ReceiptType.CLIENT) {
                        Log.d("IMPRESSAO", "Success: $it")
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = activated.value
        ) {
            Text(text = "Imprimir via cliente", fontSize = 18.sp)
        }

        Button(onClick = {
            paykit?.let { paykit ->
                paykit.printLastReceipt(ReceiptType.MERCHANT) {
                    Log.d("IMPRESSAO", "Success: $it")
                }
            }},
            modifier = Modifier.fillMaxWidth(),
            enabled = activated.value
            ) {
            Text(text = "Imprimir via loja", fontSize = 18.sp)
        }
    }
}