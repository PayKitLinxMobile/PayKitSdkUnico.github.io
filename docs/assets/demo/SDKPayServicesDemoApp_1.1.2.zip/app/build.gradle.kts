plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.jetbrains.kotlin.android)
}

val flavors = setOf(
    "stone" to 22,
    "linxtef" to 22,
    "pagseguro" to 23,
    "vero" to 22,
    "getnet" to 22,
    "rede" to 22,
    "cielo" to 24,
    "adyen" to 28,
    "sicoob" to 22,
    "sicoobX990DX" to 24,
)

android {
    namespace = "com.linx.paykit"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.linx.paykit"
        minSdk = 21
        targetSdk = 34
        versionCode = 1
        versionName = "1.1.2"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    flavorDimensions += "providers"
    productFlavors {
        flavors.forEach{
            create(it.first) {
                minSdk = it.second
            }
        }
    }

    buildFeatures {
        compose = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.10"
    }
}

dependencies {

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.navigation.fragment.ktx)
    implementation(libs.androidx.navigation.ui.ktx)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)

    val sdkPayServicesVersion = "SDK_VERSION"

    //SDK Libs
    implementation("SDKPayServices:core:$sdkPayServicesVersion")
    implementation("SDKPayServices:config:$sdkPayServicesVersion")
    implementation("SDKPayServices:common:$sdkPayServicesVersion")

    //Compose
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.compose.ui:ui:1.7.2")
    implementation("androidx.compose.ui:ui-tooling-preview:1.7.2")
    implementation("androidx.compose.material3:material3:1.3.0")
    implementation("androidx.compose.material:material-icons-extended:1.7.2")
    implementation("androidx.navigation:navigation-compose:2.6.0")
}