﻿package com.linx.paykit

import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linx.paykit.common.Callback
import com.linx.paykit.common.EnumPaymentType
import com.linx.paykit.common.ExtendedPaykit
import com.linx.paykit.common.Paykit
import com.linx.paykit.common.PaymentResult
import com.linx.paykit.common.builder.Parameters
import com.linx.paykit.common.parameter.FinancialType
import com.linx.paykit.common.parameter.PaymentParameters
import com.linx.paykit.common.parameter.ReceiptType
import com.linx.paykit.core.PaykitFactory
import com.linx.paykit.example.components.AmountInput
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.math.BigDecimal

class PaymentActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val paykit = PaykitFactory().build(Parameters(this, "AppTeste"))
        setContent {
            PaymentScreen(paykit)
        }
    }
}

@Preview
@Composable
fun PaymentScreen(paykit: Paykit? = null) {
    var paymentType by remember { mutableStateOf(EnumPaymentType.DEBITO) }
    var amount by remember { mutableStateOf(BigDecimal.ZERO) }
    var installments by remember { mutableIntStateOf(1) }
    var financialType by remember { mutableStateOf(FinancialType.ISSUER) }
    var result by remember { mutableStateOf<PaymentResult?>(null) }
    var autoConfirm by remember { mutableStateOf(true) }
    val scrollState = rememberScrollState()
    val context = LocalContext.current
    var deadline by remember { mutableIntStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(scrollState)
            .background(Color(0xFFEFEFEF)),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Tipo de pagamento",
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(bottom = 20.dp)
        )
        PaymentTypeSelector(paymentType) { paymentType = it }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = autoConfirm, onCheckedChange = { autoConfirm = it })
            Text(text = "Auto confirmar", style = MaterialTheme.typography.bodyLarge)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(text = "Valor", style = MaterialTheme.typography.bodyLarge)
        AmountInput(amount) {
            amount = it
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (paymentType == EnumPaymentType.BANRICOMPRAS_DEBITO_PREDATADO){
            Text(text = "Prazo", style = MaterialTheme.typography.labelMedium)
            TextField(
                value = if (deadline > 0) deadline.toString() else "",
                onValueChange = { newValue ->
                    val digitsOnly = newValue.filter { it.isDigit() }
                    deadline = digitsOnly.toIntOrNull() ?: 0
                },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number)
            )

            Spacer(modifier = Modifier.height(16.dp))
        }

        if (paymentType == EnumPaymentType.CREDITO || paymentType == EnumPaymentType.BANRICOMPRAS_CREDITO || paymentType == EnumPaymentType.BANRICOMPRAS_DEBITO_PARCELADO) {
            Text(text = "Número de Parcelas", style = MaterialTheme.typography.labelMedium)
            TextField(
                value = if (installments > 0) installments.toString() else "",
                onValueChange = { newValue ->
                    val digitsOnly = newValue.filter { it.isDigit() }
                    installments = digitsOnly.toIntOrNull() ?: 0
                },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number)
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (installments > 1 && paymentType != EnumPaymentType.BANRICOMPRAS_DEBITO_PARCELADO && paymentType != EnumPaymentType.BANRICOMPRAS_CREDITO) {
                Text(text = "Tipo de Financiamento", style = MaterialTheme.typography.labelMedium)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    RadioButton(selected = financialType == FinancialType.ISSUER, onClick = {
                        financialType = FinancialType.ISSUER
                    })
                    Text(text = "Emissor", style = MaterialTheme.typography.labelMedium)
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    RadioButton(selected = financialType == FinancialType.MERCHANT, onClick = {
                        financialType = FinancialType.MERCHANT
                    })
                    Text(text = "Lojista", style = MaterialTheme.typography.labelMedium)
                }
            }
        }

        Button(
            onClick = {
                paykit?.let { paykit ->
                    startPayment(
                        context,
                        paykit,
                        amount,
                        autoConfirm,
                        paymentType,
                        installments,
                        deadline,
                        financialType
                    ) { r ->
                        result = r
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
        ) {
            Text(text = "Iniciar pagamento", fontSize = 18.sp)
        }

        result?.let {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
                    .background(Color.LightGray)
                    .padding(16.dp)
            ) {
                Text(text = "Transaction id: ${it.id}", fontSize = 16.sp)
                Text(text = "Status: ${it.status}", fontSize = 16.sp)
                Text(text = "Status Message: ${it.message ?: "null"}", fontSize = 16.sp)
            }
        }

//        when (BuildConfig.FLAVOR) {
//            BuildFlavor.REDE -> {}
//            BuildFlavor.GETNET -> {}
//            else -> {
//                Button(
//                    onClick = {
//                        paykit?.let { paykit ->
//                            result?.let { result ->
//                                paykit.confirmPendingTransaction(PendingTransactionParameters(result.id!!, amount)) { success ->
//                                    Log.d("CONFIRM", "Success: $success")
//                                }
//                            }
//                        }
//                    },
//                    enabled = result?.status == TransactionStatus.PENDING,
//                    modifier = Modifier.fillMaxWidth()
//                ) {
//                    Text(text = "Confirmar", fontSize = 18.sp)
//                }
//
//                Button(
//                    onClick = {
//                        paykit?.let { paykit ->
//                            paykit.undoPendingTransaction( PendingTransactionParameters(result?.id ?:"")) { success ->
//                                Log.d("UNDO", "Success: $success")
//                            }
//                        }
//                    },
//                    enabled = result?.status == TransactionStatus.PENDING,
//                    modifier = Modifier.fillMaxWidth()
//                ) {
//                    Text(text = "Desfazer", fontSize = 18.sp)
//                }
//            }
//        }

        Button(
            onClick = {
                paykit?.let { paykit ->
                    paykit.printLastReceipt(ReceiptType.CLIENT) {
                        Log.d("IMPRESSAO", "Success: $it")
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = "Imprimir via cliente", fontSize = 18.sp)
        }

        Button(onClick = {
            paykit?.let { paykit ->
                paykit.printLastReceipt(ReceiptType.MERCHANT) {
                    Log.d("IMPRESSAO", "Success: $it")
                }
            }
        }, modifier = Modifier.fillMaxWidth()) {
            Text(text = "Imprimir via loja", fontSize = 18.sp)
        }
    }
}

fun startPayment(
    context: Context,
    paykit: Paykit,
    amount: BigDecimal,
    autoConfirm: Boolean,
    paymentType: EnumPaymentType,
    installments: Int,
    deadline: Int,
    financialType: FinancialType,
    onResult: (PaymentResult) -> Unit
) {
    val params = PaymentParameters(true, amount).apply {
        if (paymentType == EnumPaymentType.CREDITO
            || paymentType == EnumPaymentType.BANRICOMPRAS_CREDITO
            || paymentType == EnumPaymentType.BANRICOMPRAS_DEBITO_PARCELADO) {
            this.installments = if (installments > 1) installments else 1
            this.financialType =
                if (installments > 1) financialType else FinancialType.ONE_INSTALMENT
        }
        if (paymentType == EnumPaymentType.BANRICOMPRAS_DEBITO_PREDATADO) {
            this.deadline = if(deadline > 0) deadline else 0
        }
        this.automaticConfirmation = autoConfirm
        this.externalId = System.currentTimeMillis().toString()
    }
    val callback: Callback<PaymentResult> =
        Callback { t ->
            CoroutineScope(Dispatchers.IO).launch {
//                if (!t.id.isNullOrBlank()) {
//                    val history = TransactionHistory(
//                        t.id!!,
//                        paymentType,
//                        amount,
//                        Date(),
//                        t.status
//                    )
//                    AppDatabase.getInstance(context).transactionHistoryDao().insert(history)
//                }
                onResult(t)
            }
        }
    when (paymentType) {
        EnumPaymentType.DEBITO-> paykit.debit(params, callback)
        EnumPaymentType.CREDITO -> paykit.credit(params, callback)
        EnumPaymentType.VOUCHER -> paykit.voucher(params, callback)
        EnumPaymentType.PIX -> paykit.pix(params, callback)
        EnumPaymentType.WALLET -> paykit.wallet(params, callback)
        EnumPaymentType.BANRICOMPRAS_DEBITO_VISTA,
        EnumPaymentType.BANRICOMPRAS_DEBITO_PARCELADO,
        EnumPaymentType.BANRICOMPRAS_DEBITO_PREDATADO -> (paykit as ExtendedPaykit).banriDebit(params, callback)
        EnumPaymentType.BANRICOMPRAS_CREDITO -> (paykit as ExtendedPaykit).banriCredit(params, callback)
    }
}

@Composable
fun PaymentTypeSelector(
    selectedType: EnumPaymentType = EnumPaymentType.DEBITO,
    onTypeChanged: ((EnumPaymentType) -> Unit)? = null
) {
    Row(
        horizontalArrangement = Arrangement.SpaceEvenly,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(selected = selectedType == EnumPaymentType.DEBITO, onClick = {
                    onTypeChanged?.invoke(
                        EnumPaymentType.DEBITO
                    )
                })
                Text(text = "Débito", style = MaterialTheme.typography.bodyLarge)
            }
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(selected = selectedType == EnumPaymentType.CREDITO, onClick = {
                    onTypeChanged?.invoke(
                        EnumPaymentType.CREDITO
                    )
                })
                Text(text = "Crédito", style = MaterialTheme.typography.bodyLarge)
            }
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
//                RadioButton(selected = selectedType == EnumPaymentType.WALLET,
//                    enabled = BuildConfig.FLAVOR == BuildFlavor.VERO,
//                    onClick = {
//                        onTypeChanged?.invoke(
//                            EnumPaymentType.WALLET
//                        )
//                    })
                Text(text = "Wallet", style = MaterialTheme.typography.bodyLarge)
            }
        }
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(selected = selectedType == EnumPaymentType.VOUCHER, onClick = {
                    onTypeChanged?.invoke(
                        EnumPaymentType.VOUCHER
                    )
                })
                Text(text = "Voucher", style = MaterialTheme.typography.bodyLarge)
            }
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = selectedType == EnumPaymentType.PIX,
                    onClick = {
                        onTypeChanged?.invoke(
                            EnumPaymentType.PIX
                        )
                    },
                )
                Text(text = "PIX", style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
//    if (BuildConfig.FLAVOR == BuildFlavor.VERO){
//        Column{
//            Row(
//                verticalAlignment = Alignment.CenterVertically,
//            ) {
//                RadioButton(selected = selectedType == EnumPaymentType.BANRICOMPRAS_DEBITO_VISTA, onClick = {
//                    onTypeChanged?.invoke(
//                        EnumPaymentType.BANRICOMPRAS_DEBITO_VISTA
//                    )
//                })
//                Text(text = "Banricompras Débito á vista", style = MaterialTheme.typography.bodyLarge)
//            }
//            Row(
//                verticalAlignment = Alignment.CenterVertically
//            ) {
//                RadioButton(selected = selectedType == EnumPaymentType.BANRICOMPRAS_DEBITO_PREDATADO, onClick = {
//                    onTypeChanged?.invoke(
//                        EnumPaymentType.BANRICOMPRAS_DEBITO_PREDATADO
//                    )
//                })
//                Text(text = "Banricompras Débito Pré-datado", style = MaterialTheme.typography.bodyLarge)
//            }
//            Row(
//                verticalAlignment = Alignment.CenterVertically
//            ) {
//                RadioButton(selected = selectedType == EnumPaymentType.BANRICOMPRAS_DEBITO_PARCELADO, onClick = {
//                    onTypeChanged?.invoke(
//                        EnumPaymentType.BANRICOMPRAS_DEBITO_PARCELADO
//                    )
//                })
//                Text(text = "Banricompras Débito Parcelado", style = MaterialTheme.typography.bodyLarge)
//            }
//            Row(
//                verticalAlignment = Alignment.CenterVertically
//            ) {
//                RadioButton(selected = selectedType == EnumPaymentType.BANRICOMPRAS_CREDITO, onClick = {
//                    onTypeChanged?.invoke(
//                        EnumPaymentType.BANRICOMPRAS_CREDITO
//                    )
//                })
//                Text(text = "Banricompras Crédito 1 Minuto", style = MaterialTheme.typography.bodyLarge)
//            }
//        }
//    }
}

