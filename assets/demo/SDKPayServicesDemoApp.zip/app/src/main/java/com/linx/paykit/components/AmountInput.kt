package com.linx.paykit.example.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.NumberFormat
import java.util.Locale

@Composable
fun AmountInput(
    initialAmount: BigDecimal = BigDecimal.ZERO,
    onAmountChange: (BigDecimal) -> Unit
) {
    val locale = Locale.getDefault()
    val currencyFormat = remember { NumberFormat.getCurrencyInstance(locale) }

    var amount by remember { mutableStateOf(initialAmount) }
    var textFieldValue by remember { mutableStateOf(TextFieldValue(currencyFormat.format(amount))) }

    TextField(
        value = textFieldValue,
        onValueChange = { newValue ->
            val digitsOnly = newValue.text.filter { it.isDigit() || it == '.' }
            val parsedAmount = processInput(digitsOnly)
            amount = parsedAmount
            onAmountChange(amount)
            val formatted = currencyFormat.format(amount)
            textFieldValue = TextFieldValue(
                text = formatted,
                selection = TextRange(formatted.length)
            )
        },
        modifier = Modifier.fillMaxWidth(),
        keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number),
    )
}

private fun processInput(input: String): BigDecimal {
    if (input.isEmpty()) {
        return BigDecimal.ZERO
    }
    return try {
        val digits = BigDecimal(input).setScale(2, RoundingMode.FLOOR)
        digits.divide(BigDecimal(100), RoundingMode.FLOOR)
    } catch (e: NumberFormatException) {
        BigDecimal.ZERO
    }
}

