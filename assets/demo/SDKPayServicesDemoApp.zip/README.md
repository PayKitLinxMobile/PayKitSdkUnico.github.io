# SDK Único - App de Demo

Bem-vindo ao repositório da **App de Demo** do **SDK Único**. Esta aplicação Android serve como um exemplo de integração do SDK Único com diferentes funcionalidades de transações comerciais, como crédito, débito, PIX, e outras operações relacionadas.

## Visão Geral

O **SDK Único** oferece uma interface unificada para diversas integrações com SDKs de automação comercial. Este projeto de demonstração inclui exemplos de como realizar operações comuns, como transações de crédito, débito, PIX, voucher, cancelamento de transações, reimpressão de transações e cópia de dados.

### Funcionalidades Suportadas

- Transação de crédito e débito.
- Transação via PIX.
- Transações com voucher.
- Cancelamento de transações.
- Reimpressão e cópia de transações.

## Documentação

A documentação completa e detalhada pode ser encontrada no [site oficial do SDK Único](https://gabrieldavid5.github.io/sdkunico/primeiros-passos/). Lá você encontrará informações sobre a configuração, integração e exemplos de uso do SDK Único.

## Requisitos

- Android Studio 4.1 ou superior
- JDK 1.8 ou superior
- Kotlin 1.5 ou superior
- Gradle 6.5 ou superior